<footer class="bg-dark">

    <div class="container p-5 px-lg-0 py-lg-5">


        <div class="row text-white align-items-center flex-column-reverse flex-md-row">
            <div class="col-lg-6">

                <p><strong>SURVEYplus</strong> is brought to you by CITEC-HITM BATCH-9 to Shape a better driven insight and experience management survey solutions built for the pace of modern business and organizations for requirement gathering.</p>

                <p class="text-center text-lg-start">Copyright &copy; 2023 CITEC-HITM </p>

            </div>
            <div class="col-lg-6 text-center text-lg-end mb-3 mb-lg-0">
                <a href="#" class="text-white text-decoration-none fw-bolder display-5">
                    <span>survey+</span>
                </a>
            </div>
        </div>

    </div>


</footer>


   


<script src="<?= BASE_URL ?>/dist/js/bootstrap.bundle.min.js"></script>


    
</body>
</html>